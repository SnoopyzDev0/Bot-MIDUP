import discord
from discord.ext import commands
from discord import ui
from datetime import datetime, timedelta
import asyncio

TICKET_CHANNEL_ID = 1421252636321255434
COOLDOWN_MINUTOS = 1
STAFF_ROLE_ID = 1421253388602970153
ARCHIVE_CHANNEL_ID = 1421254694042341396

ticket_cooldowns = {}
active_tickets = {}  
ticket_data = {}  

class TicketsCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    class BaseModal(discord.ui.Modal):
        def __init__(self, bot, title: str, tipo: str):
            super().__init__(title=title)
            self.bot = bot
            self.tipo = tipo
            
            self.nick = discord.ui.TextInput(label="Seu nick", required=True)
            self.descricao = discord.ui.TextInput(label=f"Descrição ({tipo})", style=discord.TextStyle.paragraph, required=True)
            self.provas = discord.ui.TextInput(label="Provas / Links (opcional)", style=discord.TextStyle.paragraph, required=False)
            
            self.add_item(self.nick)
            self.add_item(self.descricao)
            self.add_item(self.provas)

        async def on_submit(self, interaction: discord.Interaction):
            now = datetime.now()
            user_id = interaction.user.id

            if user_id in ticket_cooldowns and ticket_cooldowns[user_id] > now:
                await interaction.response.send_message("⏱️ Você precisa esperar antes de abrir outro ticket.", ephemeral=True)
                return

            if user_id in active_tickets:
                await interaction.response.send_message("❌ Você já tem um ticket ativo.", ephemeral=True)
                return

            ticket_cooldowns[user_id] = now + timedelta(minutes=COOLDOWN_MINUTOS)

            try:
                embed_dm = discord.Embed(
                    title=f"✅ Ticket enviado - {self.tipo}",
                    description=(
                        f"**Nick:** {self.nick.value}\n"
                        f"**Descrição:** {self.descricao.value}\n"
                        f"**Provas / Links:** {self.provas.value if self.provas.value else 'Nenhuma'}\n"
                        "Aguarde a resposta da equipe"
                    ),
                    color=discord.Color.green()
                )
                embed_dm.set_thumbnail(url="https://cdn.discordapp.com/attachments/1416929958382800946/1417902306690863225/pngtree-sent-delivered-png-image_6523610.png?ex=68cc2bed&is=68cada6d&hm=41558746340288d02fb0f6c80d4c494db3d969564e35737af667d095943cec56&")
                await interaction.user.send(embed=embed_dm)
            except:
                await interaction.response.send_message("Não foi possível enviar DM. Ative suas DMs.", ephemeral=True)
                return

            canal = self.bot.get_channel(TICKET_CHANNEL_ID)
            if canal is None:
                await interaction.user.send("⚠️ Erro ao enviar o ticket. Contate um administrador.")
                return

            embed_staff = discord.Embed(
                title=f"🎫 Novo Ticket - {self.tipo}",
                description=(
                    f"**Usuário:** {interaction.user.mention}\n"
                    f"**Nick:** {self.nick.value}\n"
                    f"**Descrição:** {self.descricao.value}\n"
                    f"**Provas / Links:** {self.provas.value if self.provas.value else 'Nenhuma'}\n"
                    f"**Data:** <t:{int(now.timestamp())}:F>"
                ),
                color=discord.Color.blue()
            )

            view = TicketsCog.InitiateTicketView(interaction.user, self.tipo, self.nick.value, self.descricao.value, self.provas.value)
            await canal.send(embed=embed_staff, view=view)
            await interaction.response.send_message("✅ Seu ticket foi enviado com sucesso!", ephemeral=True)

    class InitiateTicketView(discord.ui.View):
        def __init__(self, user: discord.User, tipo: str, nick: str, descricao: str, provas: str):
            super().__init__(timeout=None)
            self.user = user
            self.tipo = tipo
            self.nick = nick
            self.descricao = descricao
            self.provas = provas

        @discord.ui.button(label="🚀 Iniciar Atendimento", style=discord.ButtonStyle.green, custom_id="iniciar_atendimento")
        async def iniciar_atendimento(self, interaction: discord.Interaction, button: discord.ui.Button):
           
            channel = interaction.channel
            thread_name = f"ticket-{self.user.display_name}-{self.tipo.lower().replace(' ', '-')}"
            
            thread = await channel.create_thread(
                name=thread_name,
                type=discord.ChannelType.private_thread,
                reason=f"Ticket de {self.user.display_name}"
            )

          
            await thread.add_user(self.user)
            active_tickets[self.user.id] = thread.id
            
            
            ticket_data[thread.id] = {
                'user': self.user,
                'tipo': self.tipo,
                'nick': self.nick,
                'descricao': self.descricao,
                'provas': self.provas,
                'staff': interaction.user,
                'created_at': datetime.now(),
                'messages': [],
                'status': 'aberto'
            }

           
            embed_abertura = discord.Embed(
                title="Central de Suporte - Aberta",
                description="Obrigado por entrar em contato!",
                color=discord.Color.green()
            )
            embed_abertura.add_field(
                name="",
                value=(
                    "Esta é uma resposta automática para que você saiba que seu pedido "
                    "foi recebido em nossa central. Você deve **receber uma resposta nossa "
                    "em breve por este mesmo chat.**\n\n"
                    "Caso queira acrescentar mais informações, envie uma mensagem "
                    "por esta mesma conversa. Todas as mensagens enviadas com sucesso "
                    "serão marcadas com \"✈️\".\n\n"
                    "🎮 **Para manter o ticket ativo, não desative as mensagens diretas.**"
                ),
                inline=False
            )
            embed_abertura.set_thumbnail(url="https://images-ext-1.discordapp.net/external/6k-i5XkPMxzJt3g2iVMFO4pjfPvNryJ-vyxJvpt6q9M/%3Fsize%3D240%26quality%3Dlossless/https/cdn.discordapp.com/emojis/1275052778909335672.webp?format=webp&width=115&height=115")

            
            embed_thread = discord.Embed(
                title=f"🎫 Atendimento - {self.tipo}",
                description=(
                    f"**Usuário:** {self.user.mention}\n"
                    f"**Nick:** {self.nick}\n"
                    f"**Descrição:** {self.descricao}\n"
                    f"**Provas:** {self.provas if self.provas else 'Nenhuma'}\n"
                    f"**Staff Responsável:** {interaction.user.mention}"
                ),
                color=discord.Color.orange()
            )

            try:
                await self.user.send(embed=embed_abertura)
            except:
                pass

            view = TicketsCog.TicketManagementView(self.user, self.tipo, interaction.user, thread)
            await thread.send(f"📞 {interaction.user.mention}, você iniciou o atendimento de {self.user.mention}!", embed=embed_thread, view=view)

            
            button.disabled = True
            button.label = f"✅ Atendido por {interaction.user.display_name}"
            button.style = discord.ButtonStyle.gray
            await interaction.response.edit_message(view=self)

    class TicketManagementView(discord.ui.View):
        def __init__(self, user: discord.User, tipo: str, staff: discord.User, thread):
            super().__init__(timeout=None)
            self.user = user
            self.tipo = tipo
            self.staff = staff
            self.thread = thread

        @discord.ui.button(label="Responder", style=discord.ButtonStyle.blurple, emoji="💬")
        async def responder(self, interaction: discord.Interaction, button: discord.ui.Button):
            await interaction.response.send_modal(TicketsCog.QuickResponseModal(self.user, self.tipo, self.thread))

        @discord.ui.button(label=" Templates", style=discord.ButtonStyle.gray, emoji="📋")
        async def templates(self, interaction: discord.Interaction, button: discord.ui.Button):
            view = TicketsCog.TemplateSelectView(self.user, self.thread)
            await interaction.response.send_message("📋 **Selecione um template:**", view=view, ephemeral=True)

        @discord.ui.button(label=" Gerenciar", style=discord.ButtonStyle.secondary, emoji="⚙️")
        async def gerenciar(self, interaction: discord.Interaction, button: discord.ui.Button):
            view = TicketsCog.ManagementSelectView(self.user, self.tipo, self.staff, self.thread)
            await interaction.response.send_message("⚙️ **Selecione uma ação de gerenciamento:**", view=view, ephemeral=True)

    class QuickResponseModal(discord.ui.Modal, title="💬 Resposta para o Usuário"):
        def __init__(self, user: discord.User, tipo: str, thread):
            super().__init__()
            self.user = user
            self.tipo = tipo
            self.thread = thread

            self.resposta = discord.ui.TextInput(
                label="Sua resposta",
                style=discord.TextStyle.paragraph,
                placeholder="Digite sua resposta aqui...",
                max_length=2000
            )
            self.add_item(self.resposta)

        async def on_submit(self, interaction: discord.Interaction):
            
            embed_thread = discord.Embed(
                title="📨 Resposta enviada",
                description=self.resposta.value,
                color=discord.Color.blue()
            )
            embed_thread.set_footer(text=f"Staff: {interaction.user.display_name}")
            await interaction.response.send_message(embed=embed_thread)

           
            try:
                embed_user = discord.Embed(
                    title=f"💬 Resposta da Equipe - {self.tipo}",
                    description=self.resposta.value,
                    color=discord.Color.blue()
                )
                embed_user.set_footer(text=f"Staff: {interaction.user.display_name}")
                await self.user.send(embed=embed_user)
                
                
                if self.thread.id in ticket_data:
                    ticket_data[self.thread.id]['messages'].append({
                        'author': interaction.user.display_name,
                        'content': self.resposta.value,
                        'timestamp': datetime.now(),
                        'type': 'staff_response'
                    })
                
            except:
                await interaction.followup.send("❌ Não foi possível enviar DM para o usuário.", ephemeral=True)

    class TemplateSelectView(discord.ui.View):
        def __init__(self, user: discord.User, thread):
            super().__init__(timeout=300)
            self.user = user
            self.thread = thread

        @discord.ui.select(
            placeholder="Escolha um template...",
            options=[
                discord.SelectOption(label="🛡️ Seja Staff", description="Informações sobre como ser staff", value="seja_staff"),
                discord.SelectOption(label="🎨 Seja Creator", description="Informações sobre o programa creator", value="seja_creator"),
                discord.SelectOption(label="🌐 Qual IP?", description="Informações sobre o IP do servidor", value="qual_ip"),
                discord.SelectOption(label="💰 Loja", description="Informações sobre a loja", value="loja"),
            ]
        )
        async def template_select(self, interaction: discord.Interaction, select: discord.ui.Select):
            mensagemsejastaff =  "Ficamos felizes com o seu interesse em fazer parte da nossa equipe!\n\
Para se candidatar à vaga de Aprendiz, basta clicar no botão no canal ⁠ - Minecraft⁠ para receber o seu link pessoal.\n\n\
Lembre-se dos seguintes requisitos:\n\n\
É necessário estar vinculado ao nosso servidor no Discord.\n\
Certifique-se de que suas mensagens diretas (DMs) estejam abertas.\n\n\
Caso você seja aprovado, um membro da nossa equipe entrará em contato com você.\n\
O tempo de resposta para receber uma resposta caso seja aprovado é em média de 14 dias úteis e máximo de 30 dias.\n\n\
Desejamos boa sorte em sua candidatura!\n clique [AQUI](https://discord.com/channels/1405235989848391731/1416915854263849041)"

            templates = {
                "seja_staff": {
                    "title": "🛡️ Como ser Staff",
                    "content": mensagemsejastaff
                },
                "seja_creator": {
                    "title": "🎨 Programa Creator",
                    "content": "Para participar do nosso programa creator:\n\n• Ter canal no YouTube/Twitch\n• Criar conteúdo relacionado ao servidor\n• Ter audiência engajada\n• Seguir nossas diretrizes\n\nEnvie seu portfólio para análise da equipe! Clique [AQUI](https://discord.com/channels/1405235989848391731/1416911678674698340)"
                },
                "qual_ip": {
                    "title": "🌐 IP do Servidor",
                    "content": "**IP Principal:** `dripmc.com.br`\n**Versão:** 1.8 - 1.20+"
                },
                "loja": {
                    "title": "💰 Nossa Loja",
                    "content": "🛒 LOJA🛒 Loja Oficial DripMCA loja oferece ranks exclusivos e kits incríveis, com vantagens únicas para deixar sua gameplay ainda mais divertida e competitiva!🌐 Acesse agora: Clique [AQUI](https://loja.dripmc.com.br/)"
                },
            }
            

            selected = templates[select.values[0]]
            
            
            embed_thread = discord.Embed(
                title=f"📋 Template: {selected['title']}",
                description=selected['content'],
                color=discord.Color.green()
            )
            embed_thread.set_footer(text=f"Enviado por: {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed_thread)
          
            try:
                embed_user = discord.Embed(
                    title=selected['title'],
                    description=selected['content'],
                    color=discord.Color.green()
                )
                await self.user.send(embed=embed_user)
                
                
                if self.thread.id in ticket_data:
                    ticket_data[self.thread.id]['messages'].append({
                        'author': interaction.user.display_name,
                        'content': f"Template: {selected['title']}\n{selected['content']}",
                        'timestamp': datetime.now(),
                        'type': 'template'
                    })
                    
            except:
                await interaction.followup.send("❌ Não foi possível enviar DM para o usuário.", ephemeral=True)

    class ManagementSelectView(discord.ui.View):
        def __init__(self, user: discord.User, tipo: str, staff: discord.User, thread):
            super().__init__(timeout=300)
            self.user = user
            self.tipo = tipo
            self.staff = staff
            self.thread = thread

        @discord.ui.select(
            placeholder="Escolha uma ação...",
            options=[
                discord.SelectOption(label=" Encerrar", description="Finalizar atendimento", value="encerrar", emoji="✅"),
                discord.SelectOption(label=" Apagar", description="Deletar thread", value="apagar", emoji="🗑️"),
                discord.SelectOption(label=" Notificar", description="Avisar sobre inatividade", value="notificar", emoji="⏰"),
                discord.SelectOption(label=" Resolver", description="Marcar como resolvido", value="resolver", emoji="✔️"),
                discord.SelectOption(label=" Arquivar", description="Arquivar ticket", value="arquivar", emoji="📁")
            ]
        )
        async def management_select(self, interaction: discord.Interaction, select: discord.ui.Select):
            action = select.values[0]
            
            if action == "encerrar":
                await self.encerrar_ticket(interaction)
            elif action == "apagar":
                await self.apagar_ticket(interaction)
            elif action == "notificar":
                await self.notificar_inatividade(interaction)
            elif action == "resolver":
                await self.resolver_ticket(interaction)
            elif action == "arquivar":
                await self.arquivar_ticket(interaction)

        async def encerrar_ticket(self, interaction):
            embed_encerramento = discord.Embed(
                title="Central de Suporte — Encerrado",
                description="Agradecemos a sua confiança no Midup.",
                color=discord.Color.blue()
            )
            embed_encerramento.add_field(
                name="",
                value=(
                    "Se houver qualquer outra forma de "
                    "ajudá-lo, não hesite em entrar em "
                    "contato conosco novamente. "
                    "Esperamos vê-lo novamente em "
                    "breve!"
                ),
                inline=False
            )
            embed_encerramento.add_field(
                name="NOTA:",
                value="Relembrarmos que poderá sempre consultar o histórico do seu atendimento através deste chat.",
                inline=False
            )

            try:
               
                view = TicketsCog.FeedbackView(self.thread, self.staff, self.user)
                await self.user.send(embed=embed_encerramento, view=view)
                
                await interaction.response.send_message("✅ Ticket encerrado! Aguardando feedback do usuário.", ephemeral=True)
                
                
                if self.thread.id in ticket_data:
                    ticket_data[self.thread.id]['status'] = 'encerrado'
                    
            except:
                await interaction.response.send_message("❌ Não foi possível enviar DM de encerramento.", ephemeral=True)

        async def apagar_ticket(self, interaction):
            
            if self.thread.id in ticket_data and ticket_data[self.thread.id]['status'] != 'arquivado':
                await interaction.response.send_message("❌ Você precisa arquivar o ticket antes de apagá-lo.", ephemeral=True)
                return
                
            await interaction.response.send_message("🗑️ Thread será deletada em 5 segundos...", ephemeral=True)
            await asyncio.sleep(5)
            
            
            if self.user.id in active_tickets:
                del active_tickets[self.user.id]
            if self.thread.id in ticket_data:
                del ticket_data[self.thread.id]
                
            await self.thread.delete()

        async def notificar_inatividade(self, interaction):
            embed_notif = discord.Embed(
                title="⏰ Ticket Inativo",
                description=(
                    "Seu ticket está inativo há algum tempo.\n\n"
                    "**Você tem 5 minutos para responder, caso contrário o ticket será encerrado automaticamente.**"
                ),
                color=discord.Color.yellow()
            )
            
            try:
                await self.user.send(embed=embed_notif)
                await interaction.response.send_message("⏰ Notificação de inatividade enviada!", ephemeral=True)
                
                
                await asyncio.sleep(300)  
                
                if self.thread.id in ticket_data and ticket_data[self.thread.id]['status'] == 'aberto':
                    embed_auto_close = discord.Embed(
                        title="⏱️ Ticket Encerrado Automaticamente",
                        description="Seu ticket foi encerrado devido à inatividade.",
                        color=discord.Color.red()
                    )
                    await self.user.send(embed=embed_auto_close)
                    
                    ticket_data[self.thread.id]['status'] = 'encerrado_automatico'
                    
            except:
                await interaction.response.send_message("❌ Não foi possível notificar o usuário.", ephemeral=True)

        async def resolver_ticket(self, interaction):
            embed_resolvido = discord.Embed(
                title="✔️ Ticket Resolvido",
                description="Este ticket foi marcado como resolvido pela equipe.",
                color=discord.Color.green()
            )
            
            await interaction.response.send_message(embed=embed_resolvido)
            
            
            if self.thread.id in ticket_data:
                ticket_data[self.thread.id]['status'] = 'resolvido'

        async def arquivar_ticket(self, interaction):
            if self.thread.id not in ticket_data:
                await interaction.response.send_message("❌ Dados do ticket não encontrados.", ephemeral=True)
                return
                
            data = ticket_data[self.thread.id]
            
          
            embed_arquivo = discord.Embed(
                title=f"📁 Ticket Arquivado - {data['tipo']}",
                color=discord.Color.purple()
            )
            
            embed_arquivo.add_field(name="👤 Usuário", value=data['user'].mention, inline=True)
            embed_arquivo.add_field(name="🛡️ Staff", value=data['staff'].mention, inline=True)
            embed_arquivo.add_field(name="📅 Criado em", value=f"<t:{int(data['created_at'].timestamp())}:F>", inline=True)
            embed_arquivo.add_field(name="🎮 Nick", value=data['nick'], inline=True)
            embed_arquivo.add_field(name="📝 Status", value=data['status'].title(), inline=True)
            embed_arquivo.add_field(name="💬 Mensagens", value=str(len(data['messages'])), inline=True)
            embed_arquivo.add_field(name="📋 Descrição", value=data['descricao'][:1000], inline=False)
            
            if data['provas']:
                embed_arquivo.add_field(name="🔗 Provas", value=data['provas'][:1000], inline=False)
            
            try:
                archive_channel = interaction.client.get_channel(ARCHIVE_CHANNEL_ID)
                if archive_channel:
                    await archive_channel.send(embed=embed_arquivo)
            except:
                pass
                
               
            ticket_data[self.thread.id]['status'] = 'arquivado'
            
            await interaction.response.send_message("📁 Ticket arquivado com sucesso!", ephemeral=True)

    class FeedbackView(discord.ui.View):
        def __init__(self, thread, staff, user):
            super().__init__(timeout=None)
            self.thread = thread
            self.staff = staff
            self.user = user

        @discord.ui.select(
            placeholder="Como foi o atendimento?",
            options=[
                discord.SelectOption(label=" Péssimo", value="pessimo", emoji="😞"),
                discord.SelectOption(label=" Ruim", value="ruim", emoji="😐"),
                discord.SelectOption(label=" Bom", value="bom", emoji="😊"),
                discord.SelectOption(label=" Excelente", value="excelente", emoji="🤩")
            ]
        )
        async def feedback_select(self, interaction: discord.Interaction, select: discord.ui.Select):
            feedback = select.values[0]
        
            if self.thread.id in ticket_data:
                ticket_data[self.thread.id]['feedback'] = feedback
                
            embed_thanks = discord.Embed(
                title="🙏 Obrigado pelo Feedback!",
                description=f"Você avaliou nosso atendimento como: **{feedback.title()}**",
                color=discord.Color.green()
            )
            
            await interaction.response.send_message(embed=embed_thanks)
            
           
            if self.user.id in active_tickets:
                del active_tickets[self.user.id]

    
    class DenunciaModal(BaseModal):
        def __init__(self, bot):
            super().__init__(bot, "Denúncia", "Denúncia")

    class DuvidaLojaModal(BaseModal):
        def __init__(self, bot):
            super().__init__(bot, "Dúvida Loja", "Dúvida Loja")

    class FinanceiroModal(BaseModal):
        def __init__(self, bot):
            super().__init__(bot, "Financeiro", "Financeiro")

    class ErrosModal(BaseModal):
        def __init__(self, bot):
            super().__init__(bot, "Erros e Bugs", "Erros e Bugs")

    class ConexaoModal(BaseModal):
        def __init__(self, bot):
            super().__init__(bot, "Problemas de Conexão", "Problemas de Conexão")

    
    class TicketMenuView(discord.ui.View):
        def __init__(self, bot):
            super().__init__(timeout=None)
            self.bot = bot

        @discord.ui.button(label="Denúncias", style=discord.ButtonStyle.red, custom_id="denuncias")
        async def denuncias(self, interaction: discord.Interaction, button: discord.ui.Button):
            await interaction.response.send_modal(TicketsCog.DenunciaModal(self.bot))

        @discord.ui.button(label="Dúvidas Loja", style=discord.ButtonStyle.green, custom_id="duvidas_loja")
        async def duvidas_loja(self, interaction: discord.Interaction, button: discord.ui.Button):
            await interaction.response.send_modal(TicketsCog.DuvidaLojaModal(self.bot))

        @discord.ui.button(label="Financeiro", style=discord.ButtonStyle.blurple, custom_id="financeiro")
        async def financeiro(self, interaction: discord.Interaction, button: discord.ui.Button):
            await interaction.response.send_modal(TicketsCog.FinanceiroModal(self.bot))

        @discord.ui.button(label="Erros e Bugs", style=discord.ButtonStyle.gray, custom_id="erros_bugs")
        async def erros_bugs(self, interaction: discord.Interaction, button: discord.ui.Button):
            await interaction.response.send_modal(TicketsCog.ErrosModal(self.bot))

        @discord.ui.button(label="Problemas de Conexão", style=discord.ButtonStyle.red, custom_id="conexao")
        async def conexao(self, interaction: discord.Interaction, button: discord.ui.Button):
            await interaction.response.send_modal(TicketsCog.ConexaoModal(self.bot))

    @commands.command()
    async def setuptickets(self, ctx: commands.Context):
        textoticket = (
            "# Bem-vindo ao sistema de Tickets!\n\n"
            "Aqui você pode abrir um chamado para receber suporte da nossa equipe.\n"
            "**Para usar:**\n"
            "1. Clique em algum dos botões abaixo.\n"
            "2. Explique seu problema ou dúvida de forma clara.\n"
            "3. Nossa equipe irá analisar e responder o mais rápido possível.\n\n"
            "Lembre-se:\n"
            "- Evite spam ou mensagens irrelevantes.\n"
            "- Seja claro ao descrever seu problema.\n"
            "- Cada ticket é individual, então abra apenas um por solicitação.\n\n"
            "Obrigado por utilizar nosso sistema de suporte!"
        )

        embed = discord.Embed(
            title="🔎 Atendimento | Tickets",
            description=textoticket,
            color=discord.Color.blurple()
        )
        embed.set_image(url="https://media.discordapp.net/attachments/1409652423903150131/1414033915147980970/atendimento.png")

        view = TicketsCog.TicketMenuView(self.bot)
        await ctx.send(embed=embed, view=view)

class DmResponderCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    class ResponderModal(ui.Modal):
        def __init__(self, user: discord.User):
            super().__init__(title="Responder usuário")
            self.user = user
            self.response = ui.TextInput(label="Mensagem para o usuário", style=discord.TextStyle.paragraph)
            self.add_item(self.response)

        async def on_submit(self, interaction: discord.Interaction):
            try:
                await self.user.send(embed=discord.Embed(
                    title="💬 Resposta da equipe",
                    description=self.response.value,
                    color=discord.Color.green()
                ))
                await interaction.response.send_message("✅ Mensagem enviada com sucesso!", ephemeral=True)
            except discord.Forbidden:
                await interaction.response.send_message("❌ Não foi possível enviar DM para este usuário.", ephemeral=True)

    class ResponderButton(ui.View):
        def __init__(self, user: discord.User):
            super().__init__(timeout=None)
            self.user = user

        @ui.button(label="💬 Responder", style=discord.ButtonStyle.green)
        async def responder(self, interaction: discord.Interaction, button: discord.ui.Button):
            await interaction.response.send_modal(DmResponderCog.ResponderModal(self.user))

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or message.guild:
            return

    
        try:
            await message.add_reaction("✈️")
        except discord.Forbidden:
            pass

        user_id = message.author.id

        
        if user_id in active_tickets:
            thread_id = active_tickets[user_id]
            try:
                thread = self.bot.get_channel(thread_id)
                if thread and isinstance(thread, discord.Thread):
                 
                    embed_thread = discord.Embed(
                        title="💬 Nova mensagem do usuário",
                        description=message.content,
                        color=discord.Color.blue()
                    )
                    embed_thread.set_author(
                        name=str(message.author), 
                        icon_url=message.author.display_avatar.url
                    )
                    embed_thread.timestamp = message.created_at
                    
                    await thread.send(embed=embed_thread)
                    
                    if thread_id in ticket_data:
                        ticket_data[thread_id]['messages'].append({
                            'author': message.author.display_name,
                            'content': message.content,
                            'timestamp': message.created_at,
                            'type': 'user_message'
                        })
                    
                
                    embed_confirm = discord.Embed(
                        title="✅ Mensagem Recebida",
                        description="Sua mensagem foi enviada para nossa equipe de suporte. Aguarde a resposta!",
                        color=discord.Color.green()
                    )
                    try:
                        await message.channel.send(embed=embed_confirm)
                    except discord.Forbidden:
                        pass
                    
                    return
            except Exception as e:
                print(f"Erro ao enviar mensagem para thread: {e}")
               
                if user_id in active_tickets:
                    del active_tickets[user_id]

        
        embed_suggest = discord.Embed(
            title="🎫 Abra um Ticket",
            description=(
                "Para receber suporte da nossa equipe, você precisa abrir um ticket primeiro!\n\n"
                "**Como abrir um ticket:**\n"
                "1. Vá para o canal de tickets do servidor\n"
                "2. Clique no botão correspondente ao seu problema\n"
                "3. Preencha as informações solicitadas\n\n"
                "Após abrir o ticket, você poderá conversar diretamente conosco por aqui!"
            ),
            color=discord.Color.orange()
        )
        embed_suggest.set_footer(text="💡 Dica: Suas mensagens aqui só serão respondidas se você tiver um ticket ativo!")

        try:
            await message.channel.send(embed=embed_suggest)
        except discord.Forbidden:
            print(f"Não foi possível enviar DM para {message.author}")

async def setup(bot: commands.Bot):
    await bot.add_cog(TicketsCog(bot))
    await bot.add_cog(DmResponderCog(bot))